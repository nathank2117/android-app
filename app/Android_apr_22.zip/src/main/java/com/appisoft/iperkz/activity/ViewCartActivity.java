package com.appisoft.iperkz.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.appisoft.iperkz.activity.data.LoginDataSource;
import com.appisoft.iperkz.activity.data.LoginRepository;
import com.appisoft.iperkz.adapter.OrderListAdapter;
import com.appisoft.iperkz.callback.CreateOrderRequestCallback;
import com.appisoft.iperkz.callback.MenuListServiceRequestCallback;
import com.appisoft.iperkz.converters.MenuSelectionToCustomerOrderConverter;
import com.appisoft.iperkz.data.Data;
import com.appisoft.iperkz.engine.Cronet;
import com.appisoft.iperkz.entity.FoodItem;
import com.appisoft.iperkz.entity.MenuFilterCriteria;
import com.appisoft.iperkz.entity.MenuItem;
import com.appisoft.iperkz.entity.uploader.ByteBufferUploadProvider;
import com.appisoft.iperkz.entity.CustomerOrderCreationRequest;
import com.appisoft.perkz.DisplayMessageActivity;
import com.appisoft.perkz.R;
import com.appisoft.perkz.databinding.ActivityViewCartBinding;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.chromium.net.CronetEngine;
import org.chromium.net.UploadDataProvider;
import org.chromium.net.UrlRequest;

import java.util.ArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 */
public class ViewCartActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    private LoginRepository loginRepository = LoginRepository.getInstance(new LoginDataSource());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // setContentView(R.layout.activity_view_cart);
        ActivityViewCartBinding binding = DataBindingUtil.setContentView(this, R.layout.activity_view_cart);
        binding.setMyData(Data.getInstance());

        recyclerView = (RecyclerView) findViewById(R.id.recycleView);

        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        recyclerView.setHasFixedSize(true);

        // use a linear layout manager
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        mAdapter = new OrderListAdapter(Data.getInstance().getOrderedItems());
        recyclerView.setAdapter(mAdapter);
    }

    public void processOrder(View v) {
       /*
        DialogFragment newFragment = new SpecialInstructionsDialog();
        newFragment.setCancelable(false);
        newFragment.show(getSupportFragmentManager(), "missiles");
        */


        CronetEngine cronetEngine = Cronet.getCronetEngine(this);
        CreateOrderRequestCallback createOrderCallback = new CreateOrderRequestCallback(recyclerView, this);


        Executor executor = Executors.newSingleThreadExecutor();
        UrlRequest.Builder requestBuilder = cronetEngine.newUrlRequestBuilder(
                Data.SERVER_URL + "/api/order", createOrderCallback, executor);
        requestBuilder.addHeader("Content-Type","application/json");
        requestBuilder.setHttpMethod("POST");

        ObjectMapper mapper = new ObjectMapper();
        try {
            CustomerOrderCreationRequest order = new MenuSelectionToCustomerOrderConverter().convert();
            String jsonValue = mapper.writeValueAsString(order);
            Log.println(Log.INFO, "ViewCartActivity", jsonValue);
            byte[] bytes = mapper.writeValueAsBytes(order);
            UploadDataProvider provider = ByteBufferUploadProvider.create(bytes);
            requestBuilder.setUploadDataProvider(provider, executor);

            UrlRequest request = requestBuilder.build();
            request.start();
        }catch (JsonProcessingException e) {
            e.printStackTrace();
        }


    }

    public void showSuccessMessage() {
        MenuItem[] breakfastList = Data.getInstance().getBreakfastList();
        MenuItem[] lunchList = Data.getInstance().getLunchList();
        MenuItem[] allDayList = Data.getInstance().getAllDayList();
        if ( breakfastList != null) {
            for (FoodItem item : breakfastList) {
                item.setSelected(false);
            }
        }
        if ( lunchList != null) {
            for (FoodItem item : lunchList) {
                item.setSelected(false);
            }
        }
        if ( allDayList != null) {
            for (FoodItem item : allDayList) {
                item.setSelected(false);
            }
        }
         SuccessDialogFragment fragment =
                SuccessDialogFragment.newInstance(
                        new String[]{
                                loginRepository.getCustomerEntity().getFirstName()
                                + ", "
                                + "Your order is placed."}
                                );
       fragment.show(getSupportFragmentManager(), "test");



    }

    public void showFailureMessage() {
        SuccessDialogFragment fragment = SuccessDialogFragment.newInstance(new String[]{"Failed to place order"});
        fragment.setStyle(DialogFragment.STYLE_NO_FRAME,R.style.AppTheme );
        fragment.setCancelable(false);
        fragment.show(getSupportFragmentManager(), "test");
    }


    public void moveToHomePage(View view) {
        if ( clearCart() == true) {
            Intent intent = new Intent(this, DisplayMessageActivity.class);
            finish();
            overridePendingTransition(0, 0);
            startActivity(intent);
            overridePendingTransition(0, 0);
        }
    }

    private boolean clearCart() {
        Data.getInstance().setSelectedMenuItems(new ArrayList<FoodItem>());
        Data.getInstance().clearTotalCost();
        //Data.getInstance().setGrandTotal(0.0);
        return true;
    }

}
