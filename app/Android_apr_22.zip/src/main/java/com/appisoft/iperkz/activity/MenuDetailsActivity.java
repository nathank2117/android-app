package com.appisoft.iperkz.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.appisoft.iperkz.activity.data.LoginDataSource;
import com.appisoft.iperkz.activity.data.LoginRepository;
import com.appisoft.iperkz.adapter.MenuListAdapter;
import com.appisoft.iperkz.callback.MenuListServiceRequestCallback;
import com.appisoft.iperkz.data.Data;
import com.appisoft.iperkz.engine.Cronet;
import com.appisoft.iperkz.entity.MenuFilterCriteria;
import com.appisoft.perkz.DisplayMessageActivity;
import com.appisoft.perkz.MyUrlRequestCallback;
import com.appisoft.perkz.R;
import com.appisoft.perkz.entity.DailySpecial;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.chromium.net.CronetEngine;
import org.chromium.net.UrlRequest;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class MenuDetailsActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {

    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    private int selectedMealType= -1;

    String[] breakfastSubmenu = new String[] {"ALL", "Egg Platter", "Omelettes", "Beverages"};
    String[] lunchSubmenu = new String[] {"All","Egg Platter", "Omelettes", "Appetizers", "Salad",
                        "Sandwiches", "Chineese", "Indian", "Beverages"};
    String[] alldaySubmenu = new String[] {"All","Egg Platter", "Omelettes", "Appetizers", "Salad",
            "Sandwiches", "Chineese", "Indian", "Beverages"};
    private LoginRepository loginRepository = LoginRepository.getInstance(new LoginDataSource());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_details);
        selectedMealType= R.id.topNavigationBreakfastMenuId;
        recyclerView = (RecyclerView) findViewById(R.id.recycleView);
        final androidx.appcompat.app.ActionBar supportActionBar = getSupportActionBar();
        supportActionBar.setTitle(loginRepository.getCustomerEntity().getStore().getStoreName());
        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        recyclerView.setHasFixedSize(true);

        // use a linear layout manager
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        BottomNavigationView bottomNavigationView = (BottomNavigationView)findViewById(R.id.topNavigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(this);

        //call the service to get the Data
        Intent intent = getIntent();
        String mealType = intent.getStringExtra(DisplayMessageActivity.MEAL_TYPE);
        getDataFromServer(mealType);


    }

    public RecyclerView.Adapter getAdapter() {
        return mAdapter;
    }

    public void setAdapter(RecyclerView.Adapter mAdapter) {
        this.mAdapter = mAdapter;
    }

    /*
     if (R.id.topNavigationBreakfastMenuId == menuItem.getItemId()) {
            Toast.makeText(this, " Breakfast Clicked", Toast.LENGTH_SHORT).show();
            selectedMealType = R.id.topNavigationBreakfastMenuId;
            replaceSubmenu(breakfastSubmenu, viewGrp, null);
            getDataFromServer(Data.BREAKFAST);

        }
        if (R.id.topNavigationLunchMenuId == menuItem.getItemId()) {
            Toast.makeText(this, " Lunch Clicked", Toast.LENGTH_SHORT).show();
            selectedMealType = R.id.topNavigationLunchMenuId;
            replaceSubmenu(lunchSubmenu, viewGrp, null);
            getDataFromServer(Data.LUNCH);
        }
        if (R.id.topNavigationAlldayMenuId == menuItem.getItemId()) {
            Toast.makeText(this, " All Day Clicked", Toast.LENGTH_SHORT).show();
            selectedMealType = R.id.topNavigationAlldayMenuId;
            replaceSubmenu(alldaySubmenu, viewGrp, null);
            getDataFromServer(Data.ALL_DAY);
        }
     */
    private void getDataFromServer(String mealType) {
        boolean isInCache = false;
        ViewGroup viewGrp = (ViewGroup) findViewById(R.id.horizontalScrollContainerView);
        if ( mealType != null) {
            if (mealType.equalsIgnoreCase(Data.BREAKFAST)) {
                replaceSubmenu(breakfastSubmenu, viewGrp, null);
                if (Data.getInstance().getBreakfastList() != null) {
                    isInCache = true;
                    mAdapter = new MenuListAdapter(Data.getInstance().getBreakfastList());
                    recyclerView.setAdapter(mAdapter);
                    return;
                }
            }
            if (mealType.equalsIgnoreCase(Data.LUNCH)) {
                replaceSubmenu(lunchSubmenu, viewGrp, null);
                if (Data.getInstance().getLunchList() != null) {
                    isInCache = true;
                    mAdapter = new MenuListAdapter(Data.getInstance().getLunchList());
                    recyclerView.setAdapter(mAdapter);
                    return;
                }
            }
            if (mealType.equalsIgnoreCase(Data.ALL_DAY)) {
                replaceSubmenu(alldaySubmenu, viewGrp, null);
                if (Data.getInstance().getAllDayList() != null) {
                    isInCache = true;
                    mAdapter = new MenuListAdapter(Data.getInstance().getAllDayList());
                    recyclerView.setAdapter(mAdapter);
                    return;
                }
            }
        }
        if (isInCache == false ) {
            CronetEngine cronetEngine = Cronet.getCronetEngine(this);
            MenuListServiceRequestCallback menuCallback = new MenuListServiceRequestCallback(recyclerView, this);
            MenuFilterCriteria criteria = new MenuFilterCriteria();

            criteria.setMealType(mealType);
            menuCallback.setFilterCriteria(criteria);
            UrlRequest.Callback callback = menuCallback;

            Executor executor = Executors.newSingleThreadExecutor();
            UrlRequest.Builder requestBuilder = cronetEngine.newUrlRequestBuilder(
                    Data.SERVER_URL + "/api/menu/1", callback, executor);

            UrlRequest request = requestBuilder.build();
            request.start();
        }
    }
    private void replaceSubmenu(String[] values, ViewGroup viewGrp, String selectedItem) {
        viewGrp.removeAllViews();
        if (selectedItem == null) {
            if (values.length>0) {
                selectedItem = values[0];
            }
        }


            for (int i=0,j=0; i<values.length; i++) {
                ViewGroup grp = (ViewGroup) getLayoutInflater().inflate(R.layout.textview_submenu, viewGrp);
                TextView textView = (TextView) grp.getChildAt(j);
                if (selectedItem != null && selectedItem.equalsIgnoreCase(values[i]) ) {
                    textView.setTextColor(Color.parseColor("#3F51B5"));
                    textView.setTypeface(textView.getTypeface(), Typeface.BOLD);
                }
                j=j+2;
                textView.setText(values[i]);
                if (i < values.length -1) { //NOT last item
                   // textView.setText(values[i]);
                    getLayoutInflater().inflate(R.layout.spacer_submenu, viewGrp);
                }
            }
    }

    public   boolean onNavigationItemSelected( MenuItem menuItem) {

        ViewGroup viewGrp = (ViewGroup) findViewById(R.id.horizontalScrollContainerView);
       /*
        mAdapter = new MenuListAdapter(myDataset);
        recyclerView.setAdapter(mAdapter);
        */
        if (R.id.topNavigationBreakfastMenuId == menuItem.getItemId()) {
            Toast.makeText(this, " Breakfast Clicked", Toast.LENGTH_SHORT).show();
            selectedMealType = R.id.topNavigationBreakfastMenuId;
            replaceSubmenu(breakfastSubmenu, viewGrp, null);
            getDataFromServer(Data.BREAKFAST);

        }
        if (R.id.topNavigationLunchMenuId == menuItem.getItemId()) {
            Toast.makeText(this, " Lunch Clicked", Toast.LENGTH_SHORT).show();
            selectedMealType = R.id.topNavigationLunchMenuId;
            replaceSubmenu(lunchSubmenu, viewGrp, null);
            getDataFromServer(Data.LUNCH);
        }
        if (R.id.topNavigationAlldayMenuId == menuItem.getItemId()) {
            Toast.makeText(this, " All Day Clicked", Toast.LENGTH_SHORT).show();
            selectedMealType = R.id.topNavigationAlldayMenuId;
            replaceSubmenu(alldaySubmenu, viewGrp, null);
            getDataFromServer(Data.ALL_DAY);
        }

        return true;
    }

    public void onClick(View v) {
        TextView view = (TextView) v;
        String[] menuCategoryList  = new String[0];
       /*
       String[]  = new String[] {"Egg Platter", "Omelettes", "Beverages"};
    String[] lunchSubmenu = new String[] {"Appetizers", "Salad", "Sandwiches", "Chineese", "Indian", "Beverages"};
    String[] alldaySubmenu
        */
        Toast.makeText(this, "Text Clicked: " + view.getText(), Toast.LENGTH_SHORT).show();
        if (selectedMealType == R.id.topNavigationBreakfastMenuId) {
            menuCategoryList = breakfastSubmenu;
        }
        if (selectedMealType == R.id.topNavigationLunchMenuId) {
            menuCategoryList = lunchSubmenu;
        }
        if (selectedMealType == R.id.topNavigationAlldayMenuId) {
            menuCategoryList = alldaySubmenu;
        }
        ViewGroup viewGrp = (ViewGroup) findViewById(R.id.horizontalScrollContainerView);
        String clickedMenuCategory = view.getText().toString();
        replaceSubmenu(menuCategoryList, viewGrp,clickedMenuCategory);
        view.setTextColor(Color.parseColor("#3F51B5"));
        view.setTypeface(view.getTypeface(), Typeface.BOLD);

        ((MenuListAdapter) mAdapter).getFilter().filter(view.getText());
        /*

        for (String menuCategory : menuCategoryList) {
            if (menuCategory.trim().equalsIgnoreCase(clickedMenuCategory.trim())) {
               // view.setTextColor(Color.parseColor("#3F51B5"));
                view.setTypeface(view.getTypeface(), Typeface.BOLD);
                view.setTextColor(Color.RED);
            } else {
                view.setTextColor(Color.BLACK);
                view.setTypeface(view.getTypeface(), Typeface.NORMAL);
            }
        }
        */
    }

    public void showCartDetails(View view) {
        Intent intent = new Intent(this, ViewCartActivity.class);
        //EditText editText = (EditText) findViewById(R.id.editText);
        // String message = editText.getText().toString();
        // intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);
    }

}
