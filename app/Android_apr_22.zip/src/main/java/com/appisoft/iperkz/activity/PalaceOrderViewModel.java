package com.appisoft.iperkz.activity;

import androidx.lifecycle.ViewModel;

public class PalaceOrderViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
