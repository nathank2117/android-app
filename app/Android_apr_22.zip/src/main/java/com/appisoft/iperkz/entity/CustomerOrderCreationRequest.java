package com.appisoft.iperkz.entity;

import com.fasterxml.jackson.annotation.JsonFormat;

import org.chromium.net.UploadDataProvider;
import org.chromium.net.UploadDataSink;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.sql.Date;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class CustomerOrderCreationRequest {
    private Integer storeId;
    private Integer customerId;

    private String orderCreationTime;

    private Date orderReadyTime;
    private Date orderClosedTime;
    private Integer isASAP;
    private Integer isCustomerNotified;
    private String specialInstructions;
    private String orderStatus;
    private Double totalSalePrice;
    private ArrayList<CustomerOrderMenuItemRequest> orderItems;


    public Integer getStoreId() {
        return storeId;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public String getOrderCreationTime() {
        return orderCreationTime;
    }

    public void setOrderCreationTime(String orderCreationTime) {
        this.orderCreationTime = orderCreationTime;
    }

    public Date getOrderReadyTime() {
        return orderReadyTime;
    }

    public void setOrderReadyTime(Date orderReadyTime) {
        this.orderReadyTime = orderReadyTime;
    }

    public Date getOrderClosedTime() {
        return orderClosedTime;
    }

    public void setOrderClosedTime(Date orderClosedTime) {
        this.orderClosedTime = orderClosedTime;
    }

    public Integer getIsASAP() {
        return isASAP;
    }

    public void setIsASAP(Integer isASAP) {
        this.isASAP = isASAP;
    }

    public Integer getIsCustomerNotified() {
        return isCustomerNotified;
    }

    public void setIsCustomerNotified(Integer isCustomerNotified) {
        this.isCustomerNotified = isCustomerNotified;
    }

    public String getSpecialInstructions() {
        return specialInstructions;
    }

    public void setSpecialInstructions(String specialInstructions) {
        this.specialInstructions = specialInstructions;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public Double getTotalSalePrice() {
        return totalSalePrice;
    }

    public void setTotalSalePrice(Double totalSalePrice) {
        this.totalSalePrice = totalSalePrice;
    }

    public ArrayList<CustomerOrderMenuItemRequest> getOrderItems() {
        return orderItems;
    }

    public void setOrderItems(ArrayList<CustomerOrderMenuItemRequest> orderItems) {
        this.orderItems = orderItems;
    }
}
