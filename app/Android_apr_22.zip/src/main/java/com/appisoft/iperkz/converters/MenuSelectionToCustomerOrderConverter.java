package com.appisoft.iperkz.converters;

import com.appisoft.iperkz.activity.data.LoginDataSource;
import com.appisoft.iperkz.activity.data.LoginRepository;
import com.appisoft.iperkz.data.Data;
import com.appisoft.iperkz.entity.CustomerOrderCreationRequest;
import com.appisoft.iperkz.entity.CustomerOrderMenuItemRequest;
import com.appisoft.iperkz.entity.FoodItem;
import com.appisoft.iperkz.util.DateUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;

public class MenuSelectionToCustomerOrderConverter {

    public CustomerOrderCreationRequest convert() {
        LoginRepository loginRepository = LoginRepository.getInstance(new LoginDataSource());
        CustomerOrderCreationRequest request = new CustomerOrderCreationRequest();

        request.setStoreId(loginRepository.getCustomerEntity().getStoreId());
        request.setCustomerId(loginRepository.getCustomerEntity().getCustomerId());
        request.setSpecialInstructions("Work in Progress");
        request.setTotalSalePrice(Data.getInstance().getTotalCostAsDouble());
        request.setOrderCreationTime(DateUtils.getCurrentDateAndTime());
        ArrayList<CustomerOrderMenuItemRequest> orderItems = new ArrayList<>();
        for (FoodItem item : Data.getInstance().getSelectedMenuItems()) {
            CustomerOrderMenuItemRequest orderItem = new CustomerOrderMenuItemRequest();
            orderItem.setMenuItemId(item.getMenuId());
            orderItem.setSpecialInstructions(item.getSpecialInstructions());
            orderItem.setSalePrice(item.getSalePrice());
            orderItems.add(orderItem);


        }
        request.setOrderItems(orderItems);
       return request;
    }


}
