package com.appisoft.iperkz.entity;

import java.math.BigDecimal;

public class CustomerOrderMenuItemRequest {
    private Integer customerOrderId;
    private Integer menuItemId;
    private String specialInstructions;
    private Double salePrice;

    public Integer getCustomerOrderId() {
        return customerOrderId;
    }
    public void setCustomerOrderId(Integer customerOrderId) {
        this.customerOrderId = customerOrderId;
    }
    public Integer getMenuItemId() {
        return menuItemId;
    }
    public void setMenuItemId(Integer menuItemId) {
        this.menuItemId = menuItemId;
    }
    public String getSpecialInstructions() {
        return specialInstructions;
    }
    public void setSpecialInstructions(String specialInstructions) {
        this.specialInstructions = specialInstructions;
    }
    public Double getSalePrice() {
        return salePrice;
    }
    public void setSalePrice(Double salePrice) {
        this.salePrice = salePrice;
    }
}
