package com.appisoft.iperkz.activity.ui.login;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import com.appisoft.iperkz.activity.RegistrationActivity;
import com.appisoft.iperkz.activity.data.LoginDataSource;
import com.appisoft.iperkz.activity.data.LoginRepository;
import com.appisoft.iperkz.activity.data.Result;
import com.appisoft.iperkz.activity.data.model.LoggedInUser;
import com.appisoft.perkz.DisplayMessageActivity;
import com.appisoft.perkz.R;

public class ValidateOtp extends AppCompatActivity {

    private LoginViewModel loginViewModel;
    private LoginRepository loginRepository = LoginRepository.getInstance(new LoginDataSource());
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_validate_otp);
        loginViewModel = ViewModelProviders.of(this, new LoginViewModelFactory())
                .get(LoginViewModel.class);

        final TextView titleMessageEditText = findViewById(R.id.title_message);
        final EditText pinEntryEditText = findViewById(R.id.pinEntry);
        final TextView failureMessgTextView = findViewById(R.id.failureMessg);

        titleMessageEditText.setText("Enter the 4-digit code sent to you at \n" + loginRepository.getPhoneNumber());
        final ProgressBar loadingProgressBar = findViewById(R.id.loading);
        final Context context = this;
        /*
        loginViewModel.getLoginFormState().observe(this, new Observer<LoginFormState>() {
            @Override
            public void onChanged(@Nullable LoginFormState loginFormState) {
                if (loginFormState == null) {
                    return;
                }
                loginButton.setEnabled(loginFormState.isDataValid());
                if (loginFormState.getUsernameError() != null) {
                    usernameEditText.setError(getString(loginFormState.getUsernameError()));
                }
                if (loginFormState.getPasswordError() != null) {
                    passwordEditText.setError(getString(loginFormState.getPasswordError()));
                }
            }
        });
        */
        loginViewModel.getLoginResult().observe(this, new Observer<LoginResult>() {
            @Override
            public void onChanged(@Nullable LoginResult loginResult) {
                if (loginResult == null) {
                    return;
                }
                loadingProgressBar.setVisibility(View.GONE);
                if (loginResult.getError() != null) {
                    showLoginFailed(loginResult.getError());
                }
                if (loginResult.getSuccess() != null) {
                    updateUiWithUser(loginResult.getSuccess());
                }
                setResult(Activity.RESULT_OK);

                //Complete and destroy login activity once successful

            }
        });


        pinEntryEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s,
                                          int start,
                                          int count,
                                          int after) {}

            @Override
            public void onTextChanged(CharSequence s,
                                      int start,
                                      int before,
                                      int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                /*
                if (s.toString().equals("1234")) {
                    Toast.makeText(ValidateOtp.this, "Success", Toast.LENGTH_SHORT).show();
                } else if (s.length() == "1234".length()) {
                    Toast.makeText(ValidateOtp.this, "Incorrect", Toast.LENGTH_SHORT).show();
                    pinEntryEditText.setText(null);
                }
                */
                if (s.toString().length() == 4) {
                    loadingProgressBar.setVisibility(View.VISIBLE);
                    loginViewModel.login(loginRepository.getPhoneNumber(),
                            pinEntryEditText.getText().toString(), context);
                }
            }
        });
    }

    private void updateUiWithUser(LoggedInUserView model) {
        Toast.makeText(getApplicationContext(), "SUCCESS", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(this, RegistrationActivity.class);
        //EditText editText = (EditText) findViewById(R.id.editText);
        // String message = editText.getText().toString();
        // intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);
        finish();
    }

    private void showLoginFailed(@StringRes Integer errorString) {
        final TextView failureMessgTextView = findViewById(R.id.failureMessg);
        failureMessgTextView.setVisibility(View.VISIBLE);
    }

}
