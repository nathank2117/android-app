package com.appisoft.iperkz.view;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.DialogFragment;

import com.appisoft.iperkz.activity.MenuDetailsActivity;
import com.appisoft.iperkz.activity.SpecialInstructionsDialog;
import com.appisoft.iperkz.activity.ViewCartActivity;
import com.appisoft.iperkz.callback.ImageLoadCallBack;
import com.appisoft.iperkz.data.Data;
import com.appisoft.iperkz.engine.Cronet;
import com.appisoft.iperkz.entity.FoodItem;
import com.appisoft.iperkz.entity.MenuItem;
import com.appisoft.iperkz.util.Util;
import com.appisoft.perkz.DisplayMessageActivity;
import com.appisoft.perkz.R;
import com.appisoft.perkz.entity.DailySpecial;

import org.chromium.net.CronetEngine;
import org.chromium.net.UrlRequest;

import java.util.ArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class MenuListViewItem extends LinearLayout  implements View.OnClickListener {
    MenuItem menuItem = null;
    Context context ;
    public MenuListViewItem(Context context) {
        super(context);
        this.context = context;
        initControl(context);
    }

    public void setValues(MenuItem menuItem) {

        this.menuItem = menuItem;

        TextView menuItemNameVW = (TextView)findViewById(R.id.menuItemName);
        menuItemNameVW.setText(menuItem.getMenuItemName());

        TextView menuItemDescVW = (TextView)findViewById(R.id.menuDesc);
        menuItemDescVW.setText(menuItem.getMenuItemDesc());

        TextView menuTimingsVW = (TextView)findViewById(R.id.timings);
        menuTimingsVW.setText(menuItem.getStartTime() + " to " + menuItem.getEndTime());


        TextView salePriceVW = (TextView)findViewById(R.id.salePrice);
        salePriceVW.setText("$" + Util.getFormattedDollarAmt(menuItem.getSalePrice()));

        final TextView isSelectedTextView = (TextView) findViewById(R.id.isSelected);

        //compare with ViewCart and set the field
        ArrayList<FoodItem> selectedItem = Data.getInstance().getSelectedMenuItems();
        for (FoodItem item : selectedItem) {
            if (item.getMenuId() == menuItem.getMenuId()) {
                menuItem.setSelected(true);
            }
        }
        if (menuItem.isSelected() == false) {
            isSelectedTextView.setVisibility(View.GONE);
        }

        CronetEngine cronetEngine = Cronet.getCronetEngine(this.getContext());
        ImageView view = (ImageView)findViewById(R.id.imageView);
        Button buyButton = (Button)findViewById(R.id.order);
        buyButton.setOnClickListener(this);

        UrlRequest.Callback callback = new ImageLoadCallBack(view, this.getContext());
        Executor executor = Executors.newSingleThreadExecutor();
        UrlRequest.Builder requestBuilder = cronetEngine.newUrlRequestBuilder(
                menuItem.getImageUrl(), callback, executor);

        UrlRequest request = requestBuilder.build();
        request.start();

    }

    private void initControl(Context context )
    {

        LayoutInflater inflater = (LayoutInflater)
                context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        inflater.inflate(R.layout.list_menu_view_item, this);
    }


    @Override
    public void onClick(View v) {
        Data.getInstance().getSelectedMenuItems().add(menuItem);
        Data.getInstance().setTotalCost(menuItem.getSalePrice());
        Log.println(Log.INFO, "test ", Data.getInstance().getSelectedMenuItems().size() + "");


        final TextView isSelectedTextView = (TextView) findViewById(R.id.isSelected);
        menuItem.setSelected(true);
        isSelectedTextView.setVisibility(View.VISIBLE);

        DialogFragment newFragment = new SpecialInstructionsDialog(menuItem);
        newFragment.setCancelable(false);
        newFragment.show(((MenuDetailsActivity)context).getSupportFragmentManager(), "missiles");
    }


}
