package com.appisoft.iperkz.entity;

import java.sql.Timestamp;

public class FoodItem {
    private int menuId;
    private String menuCode;
    private int storeId;
    private String menuItemName;
    private String menuItemDesc;
    private Double orgPrice;
    private Double salePrice;
    private String mealType;
    private String mealCategory;
    private Timestamp availableStartTime;
    private Timestamp availableEndTime;
    private String imageUrl;
    private String startTime;
    private String endTime;
    private boolean isSelected =false;
    private String specialInstructions;

    public int getMenuId() {
        return menuId;
    }

    public void setMenuId(int menuId) {
        this.menuId = menuId;
    }

    public String getMenuCode() {
        return menuCode;
    }

    public void setMenuCode(String menuCode) {
        this.menuCode = menuCode;
    }

    public int getStoreId() {
        return storeId;
    }

    public void setStoreId(int storeId) {
        this.storeId = storeId;
    }

    public String getMenuItemName() {
        return menuItemName;
    }

    public void setMenuItemName(String menuItemName) {
        this.menuItemName = menuItemName;
    }

    public String getMenuItemDesc() {
        return menuItemDesc;
    }
    public void setMenuItemDesc(String menuItemDesc) {
        this.menuItemDesc = menuItemDesc;
    }

    public Double getOrgPrice() {
        return orgPrice;
    }

    public void setOrgPrice(Double orgPrice) {
        this.orgPrice = orgPrice;
    }

    public Double getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(Double salePrice) {
        this.salePrice = salePrice;
    }

    public String getMealType() {
        return mealType;
    }

    public void setMealType(String mealType) {
        this.mealType = mealType;
    }

    public String getMealCategory() {
        return mealCategory;
    }

    public void setMealCategory(String mealCategory) {
        this.mealCategory = mealCategory;
    }

    public Timestamp getAvailableStartTime() {
        return availableStartTime;
    }

    public void setAvailableStartTime(Timestamp availableStartTime) {
        this.availableStartTime = availableStartTime;
    }

    public Timestamp getAvailableEndTime() {
        return availableEndTime;
    }

    public void setAvailableEndTime(Timestamp availableEndTime) {
        this.availableEndTime = availableEndTime;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public String getSpecialInstructions() {
        return specialInstructions;
    }

    public void setSpecialInstructions(String specialInstructions) {
        this.specialInstructions = specialInstructions;
    }
}
