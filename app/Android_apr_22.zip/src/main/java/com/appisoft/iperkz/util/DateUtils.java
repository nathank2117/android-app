package com.appisoft.iperkz.util;


import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;


public class DateUtils {
    public static String getSQLDateString(String inputDateString) {
		SimpleDateFormat sourceFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		Date date = null;
		try {
			date = sourceFormatter.parse(inputDateString);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        Calendar cal = Calendar.getInstance();
        TimeZone timeZone = TimeZone.getTimeZone("US/Eastern");

		cal.setTimeZone(timeZone);
        cal.setTime(date);
        String dateStr = getHours(cal) + ":" + cal.get(Calendar.MINUTE)
                    + " "
                    + ((cal.get(Calendar.AM_PM) == Calendar.AM)?"AM": "PM");
        return dateStr;
    }

    private static String getHours(Calendar cal) {
        if (cal == null) {
            return "";
        }
        if ( cal.get(Calendar.HOUR ) == 0 ) {
            return "12";
        }
        return  ( (cal.get(Calendar.HOUR)) + "");
    }

    public static String getTime(Timestamp timestamp) {
        SimpleDateFormat format = new SimpleDateFormat("h:mm a");
        Calendar cal =Calendar.getInstance();
        cal.setTimeInMillis(timestamp.getTime());
        return format.format(cal.getTime());
    }

    public static String getCurrentDateAndTime() {
        TimeZone timeZone = TimeZone.getTimeZone("US/Eastern");
        Calendar cal = Calendar.getInstance(timeZone);
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd kk:mm:ss");
        String todaysDateStr = format.format(cal.getTime());
        return todaysDateStr;
    }
}
