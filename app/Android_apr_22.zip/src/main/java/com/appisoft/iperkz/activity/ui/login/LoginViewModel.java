package com.appisoft.iperkz.activity.ui.login;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import android.content.Context;
import android.util.Patterns;

import com.appisoft.iperkz.activity.data.LoginRepository;
import com.appisoft.iperkz.activity.data.Result;
import com.appisoft.iperkz.activity.data.model.LoggedInUser;
import com.appisoft.iperkz.entity.CustomerEntity;
import com.appisoft.perkz.R;


public class LoginViewModel extends ViewModel {

    private MutableLiveData<LoginFormState> loginFormState = new MutableLiveData<>();
    private MutableLiveData<LoginResult> loginResult = new MutableLiveData<>();
    private MutableLiveData<Boolean> sendOtpResult = new MutableLiveData<>();
    private MutableLiveData<CustomerEntity> createCustomerResult = new MutableLiveData<>();

    private LoginRepository loginRepository;

    LoginViewModel(LoginRepository loginRepository) {
        this.loginRepository = loginRepository;
    }

    LiveData<LoginFormState> getLoginFormState() {
        return loginFormState;
    }

    LiveData<LoginResult> getLoginResult() {
        return loginResult;
    }

    LiveData<Boolean> getSendOtpResult() {
        return sendOtpResult;
    }

    public LiveData<CustomerEntity> getCreateCustomerResult() {
        return createCustomerResult;
    }

    public void requestOTP(String phoneNumber, Context context) {
        // can be launched in a separate asynchronous job
     loginRepository.requestOTP(phoneNumber, context, sendOtpResult);
     /*
        if (result == true) {
            sendOtpResult.setValue(true);
        } else {
            sendOtpResult.setValue(false);
        }

      */
    }

/*
    public void loginDataChanged(String username, String password) {
        if (!isUserNameValid(username)) {
            loginFormState.setValue(new LoginFormState(R.string.invalid_username, null));
        } else if (!isPasswordValid(password)) {
            loginFormState.setValue(new LoginFormState(null, R.string.invalid_password));
        } else {
            loginFormState.setValue(new LoginFormState(true));
        }
    }
*/


    public void login(String phoneNumber, String pin, Context context) {
        // can be launched in a separate asynchronous job
        loginRepository.login(phoneNumber, pin, context, loginResult);
    }

    public void creatCustomer(CustomerEntity customerEntity, Context context) {
        // can be launched in a separate asynchronous job
        loginRepository.createCustomer(customerEntity, context, createCustomerResult);
    }
/*
    public void loginDataChanged(String username, String password) {
        if (!isUserNameValid(username)) {
            loginFormState.setValue(new LoginFormState(R.string.invalid_username, null));
        } else if (!isPasswordValid(password)) {
            loginFormState.setValue(new LoginFormState(null, R.string.invalid_password));
        } else {
            loginFormState.setValue(new LoginFormState(true));
        }
    }
    */

    // A placeholder username validation check
    private boolean isUserNameValid(String username) {
        if (username == null) {
            return false;
        }
        if (username.contains("@")) {
            return Patterns.EMAIL_ADDRESS.matcher(username).matches();
        } else {
            return !username.trim().isEmpty();
        }
    }

    // A placeholder password validation check
    private boolean isPasswordValid(String password) {
        return password != null && password.trim().length() > 5;
    }
}
