package com.appisoft.iperkz.entity;

public class MenuItem extends FoodItem {

}
