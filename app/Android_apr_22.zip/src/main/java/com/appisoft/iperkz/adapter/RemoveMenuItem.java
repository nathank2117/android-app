package com.appisoft.iperkz.adapter;

import android.view.View;

import com.appisoft.iperkz.view.OrderListViewItem;

public class RemoveMenuItem extends  Object implements View.OnClickListener {
    OrderListViewItem viewItem;
    public RemoveMenuItem(OrderListViewItem item) {
        this.viewItem = item;
    }

    @Override
    public void onClick(View v) {
    }
}
