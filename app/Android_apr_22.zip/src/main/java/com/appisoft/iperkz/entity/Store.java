package com.appisoft.iperkz.entity;

public class Store {
    private int storeId;
    private String storeName;
    private String storeDesc;
    private String addressOne;
    private String addressTwo;
    private String city;
    private String state;
    private String country;
    private String website;
    private String phone;
    private String fax;
    private String email;
    private String storeStatus;
    private String notes;
    private String storeCode;

    public int getStoreId() {
        return storeId;
    }
    public void setStoreId(int storeId) {
        this.storeId = storeId;
    }
    public String getStoreName() {
        return storeName;
    }
    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }
    public String getStoreDesc() {
        return storeDesc;
    }
    public void setStoreDesc(String storeDesc) {
        this.storeDesc = storeDesc;
    }
    public String getAddressOne() {
        return addressOne;
    }
    public void setAddressOne(String addressOne) {
        this.addressOne = addressOne;
    }
    public String getAddressTwo() {
        return addressTwo;
    }
    public void setAddressTwo(String addressTwo) {
        this.addressTwo = addressTwo;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getState() {
        return state;
    }
    public void setState(String state) {
        this.state = state;
    }
    public String getCountry() {
        return country;
    }
    public void setCountry(String country) {
        this.country = country;
    }
    public String getWebsite() {
        return website;
    }
    public void setWebsite(String website) {
        this.website = website;
    }
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getFax() {
        return fax;
    }
    public void setFax(String fax) {
        this.fax = fax;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getStoreStatus() {
        return storeStatus;
    }
    public void setStoreStatus(String storeStatus) {
        this.storeStatus = storeStatus;
    }
    public String getNotes() {
        return notes;
    }
    public void setNotes(String notes) {
        this.notes = notes;
    }
    public String getStoreCode() {
        return storeCode;
    }
    public void setStoreCode(String storeCode) {
        this.storeCode = storeCode;
    }
}
