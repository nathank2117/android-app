package com.appisoft.iperkz.util;

import java.text.DecimalFormat;

public class Util {

    public static String getFormattedDollarAmt(Double value) {
        DecimalFormat format  = new DecimalFormat("##.00");

        String formattedStr =  format.format(value);
        /*
        String[] formattedStrSplit =  formattedStr.split("[.]");
        if (formattedStrSplit.length == 2) { //has decimal
            if (formattedStrSplit[1].length() == 1) { //has only 1 digit
                formattedStr += "0";
            }
        }

         */
        return formattedStr;
    }

}
