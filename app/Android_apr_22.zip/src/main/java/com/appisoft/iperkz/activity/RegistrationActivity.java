package com.appisoft.iperkz.activity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.appisoft.iperkz.activity.data.LoginDataSource;
import com.appisoft.iperkz.activity.data.LoginRepository;
import com.appisoft.iperkz.activity.data.model.RegistrationFormState;
import com.appisoft.iperkz.activity.ui.login.LoginResult;
import com.appisoft.iperkz.activity.ui.login.LoginViewModel;
import com.appisoft.iperkz.activity.ui.login.LoginViewModelFactory;
import com.appisoft.iperkz.activity.ui.login.ValidateOtp;
import com.appisoft.iperkz.callback.SendOtpRequestCallback;
import com.appisoft.iperkz.callback.StoreDetailsRequestCallback;
import com.appisoft.iperkz.callback.VerifyOtpRequestCallback;
import com.appisoft.iperkz.data.Data;
import com.appisoft.iperkz.engine.Cronet;
import com.appisoft.iperkz.entity.Credentials;
import com.appisoft.iperkz.entity.CustomerEntity;
import com.appisoft.iperkz.entity.Store;
import com.appisoft.iperkz.entity.uploader.ByteBufferUploadProvider;
import com.appisoft.perkz.DisplayMessageActivity;
import com.appisoft.perkz.R;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.chromium.net.CronetEngine;
import org.chromium.net.UploadDataProvider;
import org.chromium.net.UrlRequest;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class RegistrationActivity extends AppCompatActivity  implements View.OnClickListener {

    private  ProgressBar loadingProgressBar;
    private Button confirmButton;
    private Button submitButton;
    private TextView storeDetails;
    CustomerEntity customerItem = new CustomerEntity();
    Store store = new Store();
    private LoginRepository loginRepository = LoginRepository.getInstance(new LoginDataSource());
    private LoginViewModel loginViewModel;
    //LiveData<CustomerEntity> formData =  new MutableLiveData<>();
    private MutableLiveData<RegistrationFormState> loginFormState = new MutableLiveData<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        loginFormState.setValue(new RegistrationFormState(false));
        loginViewModel = ViewModelProviders.of(this, new LoginViewModelFactory())
                .get(LoginViewModel.class);

        loadingProgressBar = findViewById(R.id.loading);
        final EditText pinEntryEditText = findViewById(R.id.storeCode);
        final EditText regCustFirtname = findViewById(R.id.regCustomerFirstname);
        final EditText regCustLastname = findViewById(R.id.regCustomerLastname);
        final EditText regCustEmail = findViewById(R.id.regCustomerEmail);
        final String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

        confirmButton = findViewById(R.id.storeConfirmButton);
        submitButton = findViewById(R.id.regSubmitButton);
        storeDetails = findViewById(R.id.storeDetails);

        confirmButton.setOnClickListener(this);
        submitButton.setOnClickListener(this);
        pinEntryEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s,
                                          int start,
                                          int count,
                                          int after) {}

            @Override
            public void onTextChanged(CharSequence s,
                                      int start,
                                      int before,
                                      int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().length() == 4) {
                    loadingProgressBar.setVisibility(View.VISIBLE);
                    callGetStoreDetailsService(pinEntryEditText.getText().toString());
                }
            }
        });

        regCustFirtname.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s,
                                          int start,
                                          int count,
                                          int after) {}

            @Override
            public void onTextChanged(CharSequence s,
                                      int start,
                                      int before,
                                      int count) {}

            @Override
            public void afterTextChanged(Editable s) {

                loginDataChanged(regCustFirtname.getText().toString(),
                        regCustLastname.getText().toString(),
                        regCustEmail.getText().toString());
                customerItem.setFirstName(s.toString());
            }
        });


        regCustLastname.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s,
                                          int start,
                                          int count,
                                          int after) {}

            @Override
            public void onTextChanged(CharSequence s,
                                      int start,
                                      int before,
                                      int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                customerItem.setLastName(s.toString());
                loginDataChanged(regCustFirtname.getText().toString(),
                        regCustLastname.getText().toString(),
                        regCustEmail.getText().toString());
            }
        });

        regCustEmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s,
                                          int start,
                                          int count,
                                          int after) {}

            @Override
            public void onTextChanged(CharSequence s,
                                      int start,
                                      int before,
                                      int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                customerItem.setEmail(s.toString());
                loginDataChanged(regCustFirtname.getText().toString(),
                                 regCustLastname.getText().toString(),
                                regCustEmail.getText().toString());
            }
        });


        loginViewModel.getCreateCustomerResult().observe(this, new Observer<CustomerEntity>() {
            @Override
            public void onChanged(@Nullable CustomerEntity customer) {
                if (customer == null) {
                    return;
                }
                loadingProgressBar.setVisibility(View.GONE);

                if (customer.getCustomerId() <= 0 ) {
                    createCustomerFailed();
                }
                if (customer.getCustomerId() > 0) {
                    updateUiWithOtpSendSuccess(customer);
                }

                setResult(Activity.RESULT_OK);

                //Complete and destroy login activity once successful

            }
        });


        loginFormState.observe(this, new Observer<RegistrationFormState>() {
            @Override
            public void onChanged(@Nullable RegistrationFormState loginFormState) {
                if (loginFormState == null) {
                    return;
                }
                submitButton.setEnabled(loginFormState.isDataValid());
                if (loginFormState.getFirstnameError() != null) {
                    regCustFirtname.setError(getString(loginFormState.getFirstnameError()));
                }
                if (loginFormState.getLastnameError() != null) {
                    regCustLastname.setError(getString(loginFormState.getLastnameError()));
                }
                if (loginFormState.getEmailError() != null) {
                    regCustEmail.setError(getString(loginFormState.getEmailError()));
                }
            }
        });
    }


    public void loginDataChanged(String firstname, String lastname, String email) {
        if (!isFirstnameValid(firstname)) {
            loginFormState.setValue(
                    new RegistrationFormState(R.string.invalid_firstname, null,null)
            );
        } else if (!isLastnameValid(lastname)) {
            loginFormState.setValue(
                    new RegistrationFormState(null, R.string.invalid_lastname, null)
            );
        } else if (!isEmailValid(email)) {
            loginFormState.setValue(
                    new RegistrationFormState(null, null, R.string.invalid_email)
            );
        }else {
            loginFormState.setValue(new RegistrationFormState(true));
        }
    }

    private boolean isFirstnameValid(String firstname) {
        if (firstname == null) {
            return false;
        }
        if (firstname.contains("@")) {
            return false;
        } else {
            return !firstname.trim().isEmpty();
        }
    }

    private boolean isLastnameValid(String lastname) {
        if (lastname == null) {
            return false;
        }
        if (lastname.contains("@")) {
            return false;
        } else {
            return !lastname.trim().isEmpty();
        }
    }

    private boolean isEmailValid(String email) {
        if (email == null) {
            return false;
        }
        if ( email.trim().isEmpty() ) {
            return false;
        }
        return Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    private void createCustomerFailed() {
        Toast.makeText(getApplicationContext(), "Could not create customer", Toast.LENGTH_SHORT).show();
    }

    private void updateUiWithOtpSendSuccess(CustomerEntity customer) {
        customer.setStore(this.store);
        loginRepository.setCustomerEntity(customer);
        SharedPreferences.Editor editor = getSharedPreferences("CUSTOMER_DETAILS", MODE_PRIVATE).edit();
        editor.putBoolean("REGISTERED_USER", true);
        ObjectMapper mapper = new ObjectMapper();
        String customerJson = "";
        try {
            customerJson = mapper.writeValueAsString(customer);
        } catch (Exception e) {

        }
        editor.putString("CUSTOMER", customerJson);
        editor.commit();
        // Toast.makeText(getApplicationContext(), "OTP Successfuly sent", Toast.LENGTH_LONG).show();
        Intent intent = new Intent(this, DisplayMessageActivity.class);
        //EditText editText = (EditText) findViewById(R.id.editText);
        // String message = editText.getText().toString();
        // intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);
    }

    private void callGetStoreDetailsService(String storeCode) {
        try {

            CronetEngine cronetEngine = Cronet.getCronetEngine(this);
            StoreDetailsRequestCallback otpRequestCallback = new StoreDetailsRequestCallback(this );

            Executor executor = Executors.newSingleThreadExecutor();
            String url = Data.SERVER_URL + "/api/store/"+storeCode;
            UrlRequest.Builder requestBuilder = cronetEngine.newUrlRequestBuilder(
                    url, otpRequestCallback, executor);
            UrlRequest request = requestBuilder.build();
            request.start();

        } catch (Exception e) {

        }
    }

    public void showStoreDetails(Store store) {
        this.store = store;
        loadingProgressBar.setVisibility(View.GONE);
        String details = store.getStoreName() + "\n";
        details += store.getAddressOne();
        storeDetails.setText(details);
        storeDetails.setVisibility(View.VISIBLE);
        confirmButton.setVisibility(View.VISIBLE);
        submitButton.setVisibility(View.GONE);
    }

    public void showNoMatchingStoreDetails () {
        loadingProgressBar.setVisibility(View.GONE);

        storeDetails.setText("No Matches! Enter correct store code");
        storeDetails.setVisibility(View.VISIBLE);
        confirmButton.setVisibility(View.GONE);
        submitButton.setVisibility(View.GONE);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.storeConfirmButton) {

            loginDataChanged(customerItem.getFirstName(),
                    customerItem.getLastName(),
                    customerItem.getEmail());

            submitButton.setVisibility(View.VISIBLE);
        }

        if (v.getId() == R.id.regSubmitButton) {
            loadingProgressBar.setVisibility(View.VISIBLE);
            CustomerEntity customerEntity =  populateCustomerDetails();

            loginViewModel.creatCustomer(customerEntity, RegistrationActivity.this);
            submitButton.setVisibility(View.GONE);
        }
    }

    private CustomerEntity populateCustomerDetails() {

      //  item.setFirstName();

        RegistrationFormState formState = loginFormState.getValue();
        customerItem.setPhoneNumber(loginRepository.getPhoneNumber());
        customerItem.setStoreId(store.getStoreId());
        //customerItem.setPhoneNumber("2222");
        customerItem.setCompany("wip");
        return customerItem;
    }

}
