package com.appisoft.iperkz.activity.data;

import android.content.Context;

import androidx.lifecycle.MutableLiveData;

import com.appisoft.iperkz.activity.data.model.LoggedInUser;
import com.appisoft.iperkz.activity.ui.login.LoginResult;
import com.appisoft.iperkz.callback.CreateCustomerRequestCallback;
import com.appisoft.iperkz.callback.MenuListServiceRequestCallback;
import com.appisoft.iperkz.callback.SendOtpRequestCallback;
import com.appisoft.iperkz.callback.VerifyOtpRequestCallback;
import com.appisoft.iperkz.data.Data;
import com.appisoft.iperkz.engine.Cronet;
import com.appisoft.iperkz.entity.Credentials;
import com.appisoft.iperkz.entity.CustomerEntity;
import com.appisoft.iperkz.entity.MenuFilterCriteria;
import com.appisoft.iperkz.entity.uploader.ByteBufferUploadProvider;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.chromium.net.CronetEngine;
import org.chromium.net.UploadDataProvider;
import org.chromium.net.UrlRequest;

import java.io.IOException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/**
 * Class that handles authentication w/ login credentials and retrieves user information.
 */
public class LoginDataSource {
/*
    public Result<LoggedInUser> login(String username, String password) {

        try {
            // TODO: handle loggedInUser authentication
            LoggedInUser fakeUser =
                    new LoggedInUser(
                            java.util.UUID.randomUUID().toString(),
                            "Jane Doe");
            return new Result.Success<>(fakeUser);
        } catch (Exception e) {
            return new Result.Error(new IOException("Error logging in", e));
        }
    }
*/

    public void login(String phoneNumber, String pin, Context context, MutableLiveData<LoginResult> loginResult) {

        try {
            CronetEngine cronetEngine = Cronet.getCronetEngine(context);
            VerifyOtpRequestCallback verifyOtpRequestCallback = new VerifyOtpRequestCallback(context, loginResult );

            Executor executor = Executors.newSingleThreadExecutor();
            String url = Data.SERVER_URL + "/api/verify";

            UrlRequest.Builder requestBuilder = cronetEngine.newUrlRequestBuilder(
                    url, verifyOtpRequestCallback, executor);
            requestBuilder.addHeader("Content-Type","application/json");
            requestBuilder.setHttpMethod("POST");

            Credentials creds = new Credentials();
            creds.setPhoneNumber(phoneNumber);
            creds.setPin(pin);
            ObjectMapper mapper = new ObjectMapper();
            byte[] bytes = mapper.writeValueAsBytes(creds);

            UploadDataProvider provider = ByteBufferUploadProvider.create(bytes);
            requestBuilder.setUploadDataProvider(provider, executor);

            UrlRequest request = requestBuilder.build();
            request.start();
        } catch (Exception e) {

        }
    }
    public void requestOTP(String phoneNumber, Context context, MutableLiveData<Boolean> sendOtpResult ) {

        try {
            CronetEngine cronetEngine = Cronet.getCronetEngine(context);
            SendOtpRequestCallback otpRequestCallback = new SendOtpRequestCallback(context, sendOtpResult );

            Executor executor = Executors.newSingleThreadExecutor();
            String url = Data.SERVER_URL + "/api/sendotp/"+phoneNumber;
            UrlRequest.Builder requestBuilder = cronetEngine.newUrlRequestBuilder(
                    url, otpRequestCallback, executor);

            UrlRequest request = requestBuilder.build();
            request.start();

        } catch (Exception e) {

        }
    }

    public void createCustomer(CustomerEntity customer, Context context, MutableLiveData<CustomerEntity> createCustomerResult ) {

        try {
            CronetEngine cronetEngine = Cronet.getCronetEngine(context);
            CreateCustomerRequestCallback createCustomerRequestCallback = new CreateCustomerRequestCallback(context, createCustomerResult );

            Executor executor = Executors.newSingleThreadExecutor();
            String url = Data.SERVER_URL + "/api/customer";
            UrlRequest.Builder requestBuilder = cronetEngine.newUrlRequestBuilder(
                    url, createCustomerRequestCallback, executor);


            requestBuilder.addHeader("Content-Type","application/json");
            requestBuilder.setHttpMethod("POST");


            ObjectMapper mapper = new ObjectMapper();
            byte[] bytes = mapper.writeValueAsBytes(customer);

            UploadDataProvider provider = ByteBufferUploadProvider.create(bytes);
            requestBuilder.setUploadDataProvider(provider, executor);


            UrlRequest request = requestBuilder.build();
            request.start();

        } catch (Exception e) {

        }
    }




    public void logout() {
        // TODO: revoke authentication
    }
}
