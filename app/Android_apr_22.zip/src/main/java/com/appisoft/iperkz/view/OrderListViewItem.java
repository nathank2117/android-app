package com.appisoft.iperkz.view;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.appisoft.iperkz.activity.ViewCartActivity;
import com.appisoft.iperkz.adapter.RemoveMenuItem;
import com.appisoft.iperkz.callback.ImageLoadCallBack;
import com.appisoft.iperkz.data.Data;
import com.appisoft.iperkz.engine.Cronet;
import com.appisoft.iperkz.entity.FoodItem;
import com.appisoft.iperkz.entity.MenuItem;
import com.appisoft.iperkz.util.Util;
import com.appisoft.perkz.R;

import org.chromium.net.CronetEngine;
import org.chromium.net.UrlRequest;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class OrderListViewItem extends LinearLayout   {
    FoodItem foodItem = null;
    ViewCartActivity activity;
    public ImageButton deleteButton;
    public OrderListViewItem(Context context) {
        super(context);
        initControl(context);
    }

    public void setValues(FoodItem menuItem) {

        this.foodItem = foodItem;

        TextView menuItemNameVW = (TextView)findViewById(R.id.menuItemName);
        menuItemNameVW.setText(menuItem.getMenuItemName());

        TextView menuItemDescVW = (TextView)findViewById(R.id.menuDesc);
        menuItemDescVW.setText(menuItem.getMenuItemDesc());

        //TextView menuTimingsVW = (TextView)findViewById(R.id.timings);
       // menuTimingsVW.setText(menuItem.getStartTime() + " to " + menuItem.getEndTime());


        TextView salePriceVW = (TextView)findViewById(R.id.salePrice);
        salePriceVW.setText("$" + Util.getFormattedDollarAmt(menuItem.getSalePrice()));


        CronetEngine cronetEngine = Cronet.getCronetEngine(this.getContext());
        ImageView view = (ImageView)findViewById(R.id.imageView);

        deleteButton = (ImageButton)findViewById(R.id.delete_menu_item);
        //deleteButton.setOnClickListener(activity);

        UrlRequest.Callback callback = new ImageLoadCallBack(view, this.getContext());
        Executor executor = Executors.newSingleThreadExecutor();
        UrlRequest.Builder requestBuilder = cronetEngine.newUrlRequestBuilder(
                menuItem.getImageUrl(), callback, executor);

        UrlRequest request = requestBuilder.build();
        request.start();

    }

    private void initControl(Context context )
    {
        LayoutInflater inflater = (LayoutInflater)
                context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        inflater.inflate(R.layout.list_order_view_item, this);
        this.activity = (ViewCartActivity)context;
    }


}
