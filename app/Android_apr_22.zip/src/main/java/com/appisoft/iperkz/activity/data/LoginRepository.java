package com.appisoft.iperkz.activity.data;

import android.content.Context;

import androidx.lifecycle.MutableLiveData;

import com.appisoft.iperkz.activity.data.model.LoggedInUser;
import com.appisoft.iperkz.activity.ui.login.LoginResult;
import com.appisoft.iperkz.entity.CustomerEntity;

/**
 * Class that requests authentication and user information from the remote data source and
 * maintains an in-memory cache of login status and user credentials information.
 */
public class LoginRepository {

    private static volatile LoginRepository instance;

    private LoginDataSource dataSource;
    private String phoneNumber = "";
    // If user credentials will be cached in local storage, it is recommended it be encrypted
    // @see https://developer.android.com/training/articles/keystore
    private LoggedInUser user = null;
    private CustomerEntity customerEntity = null;

    // private constructor : singleton access
    private LoginRepository(LoginDataSource dataSource) {
        this.dataSource = dataSource;
    }

    public static LoginRepository getInstance(LoginDataSource dataSource) {
        if (instance == null) {
            instance = new LoginRepository(dataSource);
        }
        return instance;
    }

    public boolean isLoggedIn() {
        return user != null;
    }

    public void logout() {
        user = null;
        dataSource.logout();
    }

    private void setLoggedInUser(LoggedInUser user) {
        this.user = user;
        // If user credentials will be cached in local storage, it is recommended it be encrypted
        // @see https://developer.android.com/training/articles/keystore
    }

    public void login(String phoneNumber, String pin, Context context, MutableLiveData<LoginResult> loginResult) {
        // handle login
        dataSource.login(phoneNumber, pin, context, loginResult);
        /*
        NATHAN
        if (result instanceof Result.Success) {
            setLoggedInUser(((Result.Success<LoggedInUser>) result).getData());
        }

         */

    }

    public void requestOTP(String phoneNumber, Context context, MutableLiveData<Boolean> sendOtpResult ) {
        // handle login
        dataSource.requestOTP(phoneNumber, context, sendOtpResult);
        this.phoneNumber = phoneNumber;
    }

    public void createCustomer(CustomerEntity customerEntity, Context context, MutableLiveData<CustomerEntity> createCustomerResult) {
        // handle login
        dataSource.createCustomer(customerEntity, context, createCustomerResult);
    }


    public String getPhoneNumber() {
        return this.phoneNumber;
    }

    public CustomerEntity getCustomerEntity() {
        return customerEntity;
    }

    public void setCustomerEntity(CustomerEntity customerEntity) {
        this.customerEntity = customerEntity;
    }
}
