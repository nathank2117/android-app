package com.appisoft.iperkz.data;

import androidx.databinding.BaseObservable;
import androidx.databinding.Bindable;

import com.appisoft.iperkz.entity.FoodItem;
import com.appisoft.iperkz.entity.MenuItem;
import com.appisoft.iperkz.util.Util;
import com.appisoft.perkz.BR;


import java.util.ArrayList;

public class Data extends BaseObservable {

    private static Data data;
    private Double totalCost = 0.0;
    private Double taxes = 0.0;
    private Double grandTotal = 0.0;

    public static final String BREAKFAST = "BREAKFAST";
    public static final String LUNCH = "LUNCH";
    public static final String ALL_DAY = "ALL DAY";

    public MenuItem[] breakfastList = null;
    public MenuItem[] lunchList = null;
    public MenuItem[] allDayList = null;

    private ArrayList<FoodItem> selectedMenuItems = new ArrayList<>();

    //public static final String SERVER_URL="http://10.0.2.2:8080";
    public static final String SERVER_URL="http://ec2-18-222-172-237.us-east-2.compute.amazonaws.com:8080";
    public static synchronized Data getInstance() {
         if (data == null) {
             data = new Data();
         }
         return data;
    }

    @Bindable
    public String getTotalCost() {
        if (totalCost == 0) {
            return "";
        }
        String formatterString = "$ "
                    + Util.getFormattedDollarAmt(totalCost);

        return formatterString;
    }

    public Double getTotalCostAsDouble() {
        return totalCost;
    }

    public void clearTotalCost() {
        totalCost = 0.0;
        taxes = totalCost * 0.1;
        grandTotal = totalCost + taxes;
        notifyPropertyChanged(BR.totalCost);
    }

    public void setTotalCost(Double price) {
        totalCost = totalCost + price;
        taxes = totalCost * 0.1;
        grandTotal = totalCost + taxes;
        notifyPropertyChanged(BR.totalCost);
    }
    public void refreshTotalCost(Double price) {
        totalCost =  price;
        taxes = totalCost * 0.1;
        Double grandTotal = totalCost + taxes;
        setGrandTotal(grandTotal);
        notifyPropertyChanged(BR.totalCost);

    }

    public void recalculateTotalCost() {
        if ( selectedMenuItems != null) {
            totalCost = 0.0;
            for (FoodItem item : selectedMenuItems) {
                totalCost += item.getSalePrice();
            }
            refreshTotalCost(totalCost);
        }
    }

    @Bindable
    public String getTaxes() {
        if (totalCost == 0) {
            return "";
        }
        String formatterString = "$ "
                + Util.getFormattedDollarAmt(taxes);

        return formatterString;
    }

    @Bindable
    public String getGrandTotal() {
        if (totalCost == 0) {
            return "";
        }
        String formatterString = "$ "
                + Util.getFormattedDollarAmt(grandTotal);

        return formatterString;

    }

    public void setGrandTotal(Double grandTotal) {
        this.grandTotal = grandTotal;
    }

    public MenuItem[] getBreakfastList() {
        return breakfastList;
    }

    public void setBreakfastList(MenuItem[] breakfastList) {
        this.breakfastList = breakfastList;
    }

    public MenuItem[] getLunchList() {
        return lunchList;
    }

    public void setLunchList(MenuItem[] lunchList) {
        this.lunchList = lunchList;
    }

    public MenuItem[] getAllDayList() {
        return allDayList;
    }

    public void setAllDayList(MenuItem[] allDayList) {
        this.allDayList = allDayList;
    }

    public ArrayList<FoodItem> getSelectedMenuItems() {
        return selectedMenuItems;
    }

    public FoodItem[] getOrderedItems() {
        return selectedMenuItems.toArray(new FoodItem[selectedMenuItems.size()]);
    }

    public void setSelectedMenuItems(ArrayList<FoodItem> selectedMenuItems) {
        this.selectedMenuItems = selectedMenuItems;
    }
}
