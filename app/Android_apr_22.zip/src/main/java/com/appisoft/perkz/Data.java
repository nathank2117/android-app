package com.appisoft.perkz;

import com.appisoft.perkz.entity.DailySpecial;

import java.util.ArrayList;
import java.util.List;

public class Data {

    public static List<DailySpecial> list = new ArrayList<>();

}
