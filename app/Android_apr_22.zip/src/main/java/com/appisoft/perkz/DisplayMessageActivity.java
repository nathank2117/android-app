package com.appisoft.perkz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.app.ActionBar;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView;
import android.widget.Toast;

import com.appisoft.iperkz.activity.MenuDetailsActivity;
import com.appisoft.iperkz.activity.ViewCartActivity;
import com.appisoft.iperkz.activity.data.LoginDataSource;
import com.appisoft.iperkz.activity.data.LoginRepository;
import com.appisoft.iperkz.firebase.FirebaseService;
import com.appisoft.perkz.binding.MainActivityContract;
import com.appisoft.perkz.binding.MainActivityPresenter;
import com.appisoft.iperkz.engine.Cronet;

import org.chromium.net.CronetEngine;
import org.chromium.net.UrlRequest;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import com.appisoft.iperkz.data.Data;
import com.google.firebase.messaging.FirebaseMessaging;

public class DisplayMessageActivity extends AppCompatActivity {
    private LoginRepository loginRepository = LoginRepository.getInstance(new LoginDataSource());
    private Menu mOptionsMenu;
    public static String MEAL_TYPE = Data.BREAKFAST;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_message);

        createNotificationChannel();
      //  ActionBar actionBar = getActionBar();
        final androidx.appcompat.app.ActionBar supportActionBar = getSupportActionBar();
        supportActionBar.setTitle(loginRepository.getCustomerEntity().getStore().getStoreName());
        FirebaseMessaging.getInstance().setAutoInitEnabled(true);
        FirebaseMessaging.getInstance().subscribeToTopic(FirebaseService.TOPIC_ALL
                 + loginRepository.getCustomerEntity().getStoreId());

        Intent intent = getIntent();
        String message = intent.getStringExtra(MainActivity.EXTRA_MESSAGE);

        // Capture the layout's TextView and set the string as its text
        ViewGroup view = findViewById(R.id.testId);
        // CronetProviderInstaller.installProvider(this);
        // CronetEngine.Builder myBuilder = new CronetEngine.Builder(this);
        CronetEngine cronetEngine = Cronet.getCronetEngine(this);

        UrlRequest.Callback callback = new MyUrlRequestCallback(view, this);
        Executor executor = Executors.newSingleThreadExecutor();
        UrlRequest.Builder requestBuilder = cronetEngine.newUrlRequestBuilder(
                Data.SERVER_URL + "/api/dailyspecial/1", callback, executor);

        UrlRequest request = requestBuilder.build();
        request.start();

    }

    private void createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "My Other channel"; // getString(R.string.channel_name);
            String description = "My Description "; //getString(R.string.channel_description);
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("TEST", name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        mOptionsMenu = menu;
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);
        SearchManager searchManager =
                        (SearchManager) getSystemService(Context.SEARCH_SERVICE);
                SearchView searchView =
                        (SearchView) mOptionsMenu.findItem(R.id.search).getActionView();
                searchView.setSearchableInfo(
                        searchManager.getSearchableInfo(getComponentName()));
                searchView.setIconifiedByDefault(false);
                searchView.setSubmitButtonEnabled(true);
        // Associate searchable configuration with the SearchView
        return true;
    }


    public void displayContent(View view) {
        /*
       View viewX =  LayoutInflater.from(this).inflate(R.layout.menu_view, (ViewGroup)findViewById(R.id.bottomCard), true);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT,LinearLayout.LayoutParams.FILL_PARENT);

        addContentView(viewX, llp);
        */
    }

    public void showCartDetails(View view) {
        Intent intent = new Intent(this, ViewCartActivity.class);
        //EditText editText = (EditText) findViewById(R.id.editText);
       // String message = editText.getText().toString();
       // intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);
    }
    public void showBreakfastDetails(View view) {
       Intent intent = new Intent(this, MenuDetailsActivity.class);
        //EditText editText = (EditText) findViewById(R.id.editText);
        // String message = editText.getText().toString();
        intent.putExtra(MEAL_TYPE, Data.BREAKFAST);
        startActivity(intent);
    }
    public void showLunchDetails(View view) {
        Intent intent = new Intent(this, MenuDetailsActivity.class);
        //EditText editText = (EditText) findViewById(R.id.editText);
        // String message = editText.getText().toString();
        intent.putExtra(MEAL_TYPE, Data.LUNCH);
        startActivity(intent);
    }
    public void showAllDayDetails(View view) {
        Intent intent = new Intent(this, MenuDetailsActivity.class);
        intent.putExtra(MEAL_TYPE, Data.ALL_DAY);
        startActivity(intent);
    }



}
