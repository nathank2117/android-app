package com.appisoft.perkz;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.fragment.app.DialogFragment;

import com.appisoft.iperkz.activity.SpecialInstructionsDialog;
import com.appisoft.iperkz.callback.ImageLoadCallBack;
import com.appisoft.iperkz.data.Data;
import com.appisoft.iperkz.engine.Cronet;
import com.appisoft.iperkz.entity.FoodItem;
import com.appisoft.iperkz.util.Util;
import com.appisoft.perkz.entity.DailySpecial;

import org.chromium.net.CronetEngine;
import org.chromium.net.UrlRequest;

import java.util.ArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class MenuView extends LinearLayout implements View.OnClickListener {
    DailySpecial dailySpecial = null;
    Context context ;
     public MenuView(Context context) {
        super(context);
        initControl(context);
    }

    public MenuView(Context context, DailySpecial dailySpecial) {
        super(context);
        this.context = context;
        this.dailySpecial = dailySpecial;
        if (this.dailySpecial.isPlaceHolder() == true) {
            initControl_nodata(context);
        } else {
            initControl(context);
            final TextView menuItemNameVW = (TextView) findViewById(R.id.menuItemName);
            menuItemNameVW.setText(dailySpecial.getMenuItemName());

            final TextView menuItemDescVW = (TextView) findViewById(R.id.menuDesc);
            menuItemDescVW.setText(dailySpecial.getMenuItemDesc());

            final TextView menuTimingsVW = (TextView) findViewById(R.id.timings);
            menuTimingsVW.setText(dailySpecial.getStartTime() + " to " + dailySpecial.getEndTime());

            final TextView salePriceVW = (TextView) findViewById(R.id.salePrice);
            salePriceVW.setText("$" + Util.getFormattedDollarAmt(dailySpecial.getSalePrice()));

            final TextView isSelectedTextView = (TextView) findViewById(R.id.isSelected);

            //compare with ViewCart and set the field
           ArrayList<FoodItem> selectedItem = Data.getInstance().getSelectedMenuItems();
           for (FoodItem item : selectedItem) {
               if (item.getMenuId() == dailySpecial.getMenuId()) {
                   dailySpecial.setSelected(true);
               }
           }
            if (dailySpecial.isSelected() == false) {
                isSelectedTextView.setVisibility(View.GONE);
            }

            Button buyButton = (Button) findViewById(R.id.order);
            buyButton.setOnClickListener(this);
        }

        CronetEngine cronetEngine = Cronet.getCronetEngine(this.getContext());
        ImageView view = (ImageView)findViewById(R.id.imageView);

        UrlRequest.Callback callback = new ImageLoadCallBack(view, this.getContext());
        Executor executor = Executors.newSingleThreadExecutor();
        UrlRequest.Builder requestBuilder = cronetEngine.newUrlRequestBuilder(
                dailySpecial.getImageUrl(), callback, executor);

        UrlRequest request = requestBuilder.build();
        request.start();

    }

    private void initControl(Context context )
    {
        LayoutInflater inflater = (LayoutInflater)
                context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.menu_view, this);

    }

    private void initControl_nodata(Context context )
    {
        LayoutInflater inflater = (LayoutInflater)
                context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.menu_view_no_data, this);
    }


    @Override
    public void onClick(View v) {
        final TextView isSelectedTextView = (TextView) findViewById(R.id.isSelected);
        Data.getInstance().getSelectedMenuItems().add(dailySpecial);
        Data.getInstance().setTotalCost(dailySpecial.getSalePrice());
        dailySpecial.setSelected(true);
        isSelectedTextView.setVisibility(View.VISIBLE);

        DialogFragment newFragment = new SpecialInstructionsDialog(dailySpecial);
        newFragment.setCancelable(false);
        newFragment.show(((DisplayMessageActivity)context).getSupportFragmentManager(), "missiles");

    }


}
